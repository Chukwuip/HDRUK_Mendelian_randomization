colnames(ukb_qced_black_ids)[2]<-"FID"

colnames(black_sr)[2]<-"FID"

#merge two data sets
qblack<-merge(ukb_qced_black_ids, black_sr, key=FID)

#colnames(qblackpcs)[2]<-"FID"

#merge two data sets
qblackpcs<-merge(qblackpcs, black_pcs, key=IID)

#qblackpcs3<-merge(qblackpcs2, black_pcs, key=IID)

colnames(qblack)[2]<-"idno"

blackdata<-merge(qblack, analysis, key=idno)

#Save Black data

library(tidyverse)
#save(blackdata, file="Z:/Ifeanyi/blackdata.txt")

#remove blacks from the analysis data
nonblacks<-analysis[!(analysis$race ==3),]

#Save the data
save(nonblacks, file="Z:/Ifeanyi/nonblackdata.rdata")

#Save black data
#Save the data
save(blackdata, file="C:/Users/Owner/Desktop/R/Internship/blackdata.Rdata")
save(nonblacks, file="C:/Users/Owner/Desktop/R/Internship/nonblacks.Rdata")
save(analysis, file="C:/Users/Owner/Desktop/R/Internship/ukb_all.Rdata")

load(file="Z:/Ifeanyi/blackdata.rdata")

#blackkdata1<-load(file="Z:/Ifeanyi/blackdata.rdata")

#save blackdata
save(blackdata, file="Z:/Ifeanyi/blackdata.Rdata")

#save blackdata
save(black_sr, file="Z:/Ifeanyi/black_sr.Rdata")

rm(black_sr)
load(file="Z:/Ifeanyi/black_sr.Rdata")


#Do data Visualization 

library(ggplot2)

bs.plot<- ggplot(blackdata, aes(x=sex))+
  geom_bar(color="blue", fill=rgb(0.1,0.4,0.5,0.7))+
  labs(title="Sex of black cohorts", x= "sex", y= "Number of individuals")

#create a categorical age group
#blackdata$ages[blackdata$ages >= 65] <- "65-70"
#blackdata$ages[blackdata$ages >=60 & blackdata$ages < 65] <- "60-64"
#blackdata$ages[blackdata$ages >=55 & blackdata$ages < 60] <- "55-59"
#blackdata$ages[blackdata$ages >=50 & blackdata$ages < 55] <- "50-54"
#blackdata$ages[blackdata$ages >=45 & blackdata$ages < 50] <- "50-45"
#blackdata$ages[blackdata$ages <= 44] <- "40-44"




#ggplot(blackdata, aes(x=ages))+
 #geom_bar(color="blue", fill=rgb(0.1,0.4,0.5,0.7))+
  #labs(title="Age of black cohorts", x= "Age", y= "Number of individuals")

library(ggplot2)
library(maps)
worldmap=map_data('world')

#look at the data
knitr::kable(head(worldmap, 5))

#plot the map

ggplot()+
  geom_polygon(data = worldmap,
               aes(x= long, y= lat, group= group))

#plot specifically for uk

ggplot()+
  geom_polygon(data = worldmap,
               aes(x= long, 
                   y= lat, 
                   group= group))+
  coord_fixed(ratio=1.5,
              xlim= c(-10, 3),
              ylim= c(50.3, 59))

#add colour to the map
ggplot()+
  geom_polygon(data = worldmap,
               aes(x= long, y= lat, 
                   group= group),
               fill= 'gray90',
               color='black')+
  coord_fixed(ratio=1.5,
              xlim= c(-10, 3),
              ylim= c(50.3, 59))+
  theme_void()
#add more coloum to analysis
analysis[c("centre_name")]<-c(analysis$centre)
#add more column to non black
nonblacks[c("centre_name")]<-c(nonblacks$centre)
#add for blacks
blackdata[c("centre_name")]<-c(blackdata$centre)

#arrange the data set
library(tidyverse)
#for all data set
analysis<- analysis %>%
  select(idno, centre, centre_name, everything())
#for non black data set
nonblacks<- nonblacks %>%
  select(idno, centre, centre_name, everything())
#for blacks
blackdata<- blackdata %>%
  select(idno, centre, centre_name, everything())

#Next change the values of centre_name to actual name
blackdata$centre_name[blackdata$centre_name %in% c("11012","11021", "11011", "11008",
                                                   "11003", "11024", "11020", "11005",
                                                   "11004", "11018", "11010", "11016"
                                                   "11001", "11017", "11009", "11013",
                                                   "11002", "11007", "11014", "11003",
                                                   "11006", "11022", "11023", "11025",
                                                   "11026", "11027", "11028")] <- ("Barts", "Birmingham", "Bristol",
                                                                                   "Bury", "Cardiff", "Cheadle (revisit)", 
                                                                                   "Croydon", "Edinburgh", "Glasgow", 
                                                                                   "Hounslow", "Leeds", "Liverpool", 
                                                                                   "Manchester", "Middlesborough", "Newcastle", 
                                                                                  "Nottingham", "Oxford", "Reading", 
                                                                                   "Sheffield", "Stockport (pilot)", "Stoke", 
                                                                                   "Swansea", "Wrexham", "Cheadle (imaging)", 
                                                                                   "Reading (imaging)", "Newcastle (imaging)", "Bristol (imaging)")


colnames(qblack)[2]<-"FID"

#merge two data sets
qblack1<-merge(qblack, ukb_self_reported_black_pcs, key=FID)

quit()
