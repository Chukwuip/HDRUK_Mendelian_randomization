
if (!require("pacman")) install.packages("pacman")
pacman::p_load(MendelianRandomization)
setwd("C:/Users/owner/Desktop/R/Internship/Fishsnps") #Change with your location
#ratio.all<-as.matrix(read.csv("summarized_data.csv", row=1))
Oilyfish = read.csv("nonoilyfish_CHD.csv")
attach(Oilyfish) #Attach coursedata to the R search path 
detach(Oilyfish)
#rm(ukbfish)
MRObject = mr_input(bx = beta.exposure, bxse = se.exposure, 
                    by = beta.outcome, byse = se.outcome,snps = SNP)
#bx.all=ratio.all["bx",]
#by.all=ratio.all["by",]
#bxse.all=ratio.all["bxse",]
#byse.all=ratio.all["byse",]
#MRObject = mr_input(bx = bx.all, bxse = bxse.all, by = by.all, byse = byse.all)

mr_ivw(MRObject, model = "fixed")

mr_ivw(MRObject, model = "random")


# scatter plot
mr_plot(MRObject,  orientate=TRUE, interactive = FALSE)


mr_allmethods(MRObject , method="main")

mr_plot(mr_allmethods(MRObject , method="main"),
        orientate=TRUE, error=TRUE)



mr_egger(MRObject,
         robust = FALSE,
         penalized = FALSE,
         correl = FALSE,
         distribution = "normal",
         alpha = 0.05)

#help("mr_egger")

# single snp plot
mr_forest(MRObject, ordered=TRUE)

mr_forest(mr_allmethods(MRObject , method="main"))

# leave one out plot
mr_loo(MRObject)

# funnel plot
mr_funnel(MRObject)
