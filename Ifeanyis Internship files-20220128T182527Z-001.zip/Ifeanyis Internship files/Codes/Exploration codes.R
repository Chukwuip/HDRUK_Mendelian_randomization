library(tidyverse)
setwd("~/Desktop/R")
write_csv(blackanalysis2, "blackanalysis2.csv")
#save(list=blackanalysis2,file="c:/blackanalysis.rdata")


#Work codes

colnames(ukb_qced_black_ids)[2]<-"FID"

colnames(black_sr)[2]<-"FID"

#merge two data sets
qblack<-merge(ukb_qced_black_ids, black_sr, key=FID)

#colnames(qblackpcs)[2]<-"FID"

#merge two data sets
qblackpcs<-merge(qblackpcs, black_pcs, key=IID)

#qblackpcs3<-merge(qblackpcs2, black_pcs, key=IID)

colnames(qblack)[2]<-"idno"

blackdata<-merge(qblack, analysis, key=idno)

#Save Black data

library(tidyverse)
#save(blackdata, file="Z:/Ifeanyi/blackdata.txt")

#remove blacks from the analysis data
nonblacks<-analysis[!(analysis$race ==3),]

#Save the data
save(nonblacks, file="Z:/Ifeanyi/nonblackdata.rdata")

#Save black data
#Save the data
save(blackdata, file="C:/Users/Owner/Desktop/R/Internship/blackdata.Rdata")
save(nonblacks, file="C:/Users/Owner/Desktop/R/Internship/nonblacks.Rdata")
save(analysis, file="C:/Users/Owner/Desktop/R/Internship/ukb_all.Rdata")

load(file="Z:/Ifeanyi/blackdata.rdata")

#blackkdata1<-load(file="Z:/Ifeanyi/blackdata.rdata")

#save blackdata
save(blackdata, file="Z:/Ifeanyi/blackdata.Rdata")

#save blackdata
save(black_sr, file="Z:/Ifeanyi/black_sr.Rdata")

rm(black_sr)
load(file="Z:/Ifeanyi/black_sr.Rdata")


#Do data Visualization 

library(ggplot2)

bs.plot<- ggplot(blackdata, aes(x=sex))+
  geom_bar(color="blue", fill=rgb(0.1,0.4,0.5,0.7))+
  labs(title="Sex of black cohorts", x= "sex", y= "Number of individuals")

#create a categorical age group
#blackdata$ages[blackdata$ages >= 65] <- "65-70"
#blackdata$ages[blackdata$ages >=60 & blackdata$ages < 65] <- "60-64"
#blackdata$ages[blackdata$ages >=55 & blackdata$ages < 60] <- "55-59"
#blackdata$ages[blackdata$ages >=50 & blackdata$ages < 55] <- "50-54"
#blackdata$ages[blackdata$ages >=45 & blackdata$ages < 50] <- "50-45"
#blackdata$ages[blackdata$ages <= 44] <- "40-44"




#ggplot(blackdata, aes(x=ages))+
#geom_bar(color="blue", fill=rgb(0.1,0.4,0.5,0.7))+
#labs(title="Age of black cohorts", x= "Age", y= "Number of individuals")

library(ggplot2)
library(maps)
worldmap=map_data('world')

#look at the data
knitr::kable(head(worldmap, 5))

#plot the map

ggplot()+
  geom_polygon(data = worldmap,
               aes(x= long, y= lat, group= group))

#plot specifically for uk

ggplot()+
  geom_polygon(data = worldmap,
               aes(x= long, 
                   y= lat, 
                   group= group))+
  coord_fixed(ratio=1.5,
              xlim= c(-10, 3),
              ylim= c(50.3, 59))

#add colour to the map
ggplot()+
  geom_polygon(data = worldmap,
               aes(x= long, y= lat, 
                   group= group),
               fill= 'gray90',
               color='black')+
  coord_fixed(ratio=1.5,
              xlim= c(-10, 3),
              ylim= c(50.3, 59))+
  theme_void()
#add more coloum to analysis
analysis[c("centre_name")]<-c(analysis$centre)
#add more column to non black
nonblacks[c("centre_name")]<-c(nonblacks$centre)
#add for blacks
blackdata[c("centre_name")]<-c(blackdata$centre)

#arrange the data set
library(tidyverse)
#for all data set
analysis<- analysis %>%
  select(idno, centre, centre_name, everything())
#for non black data set
nonblacks<- nonblacks %>%
  select(idno, centre, centre_name, everything())
#for blacks
blackdata<- blackdata %>%
  select(idno, centre, centre_name, everything())

#Next change the values of centre_name to actual name
blackdata$centre_name[blackdata$centre_name %in% c("11012","11021", "11011", "11008",
                                                   "11003", "11024", "11020", "11005",
                                                   "11004", "11018", "11010", "11016"
                                                   "11001", "11017", "11009", "11013",
                                                   "11002", "11007", "11014", "11003",
                                                   "11006", "11022", "11023", "11025",
                                                   "11026", "11027", "11028")] <- ("Barts", "Birmingham", "Bristol",
                                                                                   "Bury", "Cardiff", "Cheadle (revisit)", 
                                                                                   "Croydon", "Edinburgh", "Glasgow", 
                                                                                   "Hounslow", "Leeds", "Liverpool", 
                                                                                   "Manchester", "Middlesborough", "Newcastle", 
                                                                                   "Nottingham", "Oxford", "Reading", 
                                                                                   "Sheffield", "Stockport (pilot)", "Stoke", 
                                                                                   "Swansea", "Wrexham", "Cheadle (imaging)", 
                                                                                   "Reading (imaging)", "Newcastle (imaging)", "Bristol (imaging)")


colnames(qblack)[2]<-"FID"

#merge two data sets
qblack1<-merge(qblack, ukb_self_reported_black_pcs, key=FID)


#merge two data sets, black_sr and black_pcs
blacksr_pcs<-merge(black_sr, black_pcs, key=FID)#this did not produce the desired outcome
rm(blacksr_pcs)#therefore, outcome is removed

colnames(black_sr)[2]<-"idno"

colnames(black_sr)[3]<-"FID"

#merge two data sets, black_sr and black_pcs
blacksr_pcs<-merge(black_sr, black_pcs, key=FID)#this returns the desired outcome

#Next, this should be merged with the qblacks
rm(qblackpcs)
qblack_pcs<-merge(blacksr_pcs, qblack, key=FID)#not desired result
rm(qblack_pcs)

#rename the columns to match with that of blacksr_pcs
colnames(qblack)[1]<-"FID"

colnames(qblack)[2]<-"idno"

qblack_pcs<-merge(blacksr_pcs, qblack, key=indo)#result is desired

library(tidyverse)
#Save the data
save(qblack_pcs, file="C:/Users/Owner/Desktop/R/Internship/qblackpcs.Rdata")
load(file="C:/Users/Owner/Desktop/R/Internship/qblackpcs.Rdata")
load(file="C:/Users/Owner/Desktop/R/Internship/blackdata.Rdata")
rm(blackdata)
load(file="C:/Users/Owner/Desktop/R/Internship/blackdata.Rdata")

#merge two data sets, black_sr and black_pcs
qblackpcs<-merge(qblack_pcs, blackdata, key=idno)#this returns the desired outcome


#next do Pac
#import ggplot2 and ggfortify
library(ggplot2)
pcplot<-ggplot(data = qblack_pcs, aes(x = PC1, y = PC2)) +
  geom_point()
pcplot
pcplot<-ggplot(data = qblack_pcs, aes(x = PC1, y = PC2)) +
  geom_hline(yintercept = 0, lty = 2) +
  geom_vline(xintercept = 0, lty = 2) +
  geom_point(alpha = 0.8)
pcplot

plot(qblack_pcs)


ggplot(data = qblack_pcs, aes_all()) +
  geom_hline(yintercept = 0, lty = 2) +
  geom_vline(xintercept = 0, lty = 2) +
  geom_point(alpha = 0.8)


summary(qblack_pcs[c(5:24)])

plot(qblack_pcs[c(5:24)], type = "l")

plot(qblack_pcs, type = "l")

#ggplot(qblack_pcs, aes(PC1, PC2, col = UKB_sample_ID, fill = UKB_sample_ID)) +
  #stat_ellipse(geom = "polygon", col = "black", alpha = 0.5)+
  geom_point(shape = 21, col = "black")

#ggplot(qblack_pcs, aes(PC1, PC2, col = UKB_sample_ID, fill = UKB_sample_ID)) +
  geom_point()

ggplot(qblack_pcs, aes(PC1, PC2)) +
  stat_ellipse(geom = "polygon", col = "black", alpha = 0.5)+
  geom_point(shape = 21)
 
ggplot(qblackpcs, aes(PC1, PC3, color = idno)) +
  geom_point(shape = 21)
ggplot(qblack_pcs, aes(PC1, PC4, color = idno)) +
  geom_point(shape = 21)

#plot for years in education and sex
ggplot(qblackpcs, aes(PC1, PC2))+
  geom_point(mapping = aes(color = edyrs))+
  geom_smooth()+
  facet_wrap(~sex, nrow = 2)+
  ggtitle("PCA Plot of PC1 vs PC2 for Years in edu and Sex")+
  xlab("PC1")+
  ylab("PC2")

ggplot(qblackpcs, aes(PC1, PC2))+
  geom_point(mapping = aes(color = edyrs))+
  geom_smooth()+
  facet_wrap(~smallbin, nrow = 2)+
  ggtitle("PCA Plot of PC1 vs PC2 for Years in edu and Smoking status")+
  xlab("PC1")+
  ylab("PC2")

ggplot(qblackpcs, aes(PC1, PC2))+
  geom_point(mapping = aes(color = edyrs))+
  geom_smooth(mapping = aes(color = ages))+
  facet_wrap(~alcallbin, nrow = 2)+
  ggtitle("PCA Plot of PC1 vs PC2 for Alcohol and Age")+
  xlab("PC1")+
  ylab("PC2")

ggplot(qblack_pcs[c(5:24)]))+
  geom_bar(mapping = aes(PC1))


install.packages( "http://www.well.ox.ac.uk/~gav/resources/rbgen_v1.1.5.tgz") #, repos = NULL, type = "source" )
 library(bgen)

#load(file="C:/Users/Owner/Desktop/R/Internship/rbgen_v1.1.5.tgz")
library(tidyverse)

#load(file="Z:/AdiposityID_sampleset")

Adiposity <- read.table("z:\\AdiposityID_sampleset", header=TRUE, sep="\t")

library(tidyverse)
rm(AdiposityID_sampleset)
rm(Adiposity)
#load(file="Z:/fish.r")

qEur_pcs<-Eur_QCp_PCs[c(1:22)]

colnames(AdiposityID_sampleset)[2]<-"FID"

#merge two data sets, black_sr and black_pcs
qEuridpc<-merge(AdiposityID_sampleset[c(1:2)], qEur_pcs, key=FID)#this returns the desired outcome

library(tidyverse)

colnames(qEuridpc)[2]<-"idno"

#qEuridpc %>%
  #select(idno, FID, IID, everything())


Eurdata<-merge(qEuridpc, analysis, key=idno)

qblackpcs$FID = NULL
qblackpcs$BP_sample_ID = NULL
colnames(qblackpcs)[1]<-"FID"

qblackpcs<-qblackpcs %>%
  select(idno, FID, IID, everything())

EurBlack <- rbind(Eurdata, qblackpcs)

save(EurBlack, file="C:/Users/Owner/Desktop/R/Internship/EurAfr.Rdata")
save(Eurdata, file="C:/Users/Owner/Desktop/R/Internship/Eur_pc_data.Rdata")

library(ggplot2)
#plot for race
ggplot(EurBlack, aes(PC1, PC2))+
  geom_point(mapping = aes(color = race))+
  geom_smooth()+
  ggtitle("PCA Plot of PC1 vs PC2 for race")+
  xlab("PC1")+
  ylab("PC2")
help("ggplot")

#plot for race
ggplot(EurBlack, aes(PC1, PC2))+
  geom_point()

EurBlack
lvl.100010 <- c(1,3)
lbl.100010 <- c("European","African")
EurBlack$race <- ordered(EurBlack$race, levels=lvl.100010, labels=lbl.100010)

library(tidyverse)
#Next change the values of race from numbers to Strings
EurBlack1<- EurBlack
EurBlack1$race <- as.character(EurBlack$race)
EurBlack1$race[EurBlack1$race == "1"] <- "EUR"
EurBlack1$race[EurBlack1$race == "3"] <- "AFR"                                                                                 

library(ggplot2)
#plot for race
ggplot(EurBlack1, aes(PC1, PC2, col = race))+
  geom_point()

ggplot(EurBlack1, aes(PC1, PC2))+
  geom_point(mapping = aes(color = race))+
  facet_wrap(~smallbin, nrow = 2)+
  ggtitle("PCA Plot of PC1 vs PC2 for race and Smoking status")+
  xlab("PC1")+
  ylab("PC2")

ggplot(EurBlack1, aes(PC1, PC2))+
  geom_point(mapping = aes(color = race, shape = race))+
  facet_wrap(~smallbin, nrow = 2)+
  ggtitle("PCA Plot of PC1 vs PC2 for race and Smoking status")+
  xlab("PC1")+
  ylab("PC2")



ggplot(EurBlack1, aes(PC1, PC2))+
  geom_point(mapping = aes(color = race, shape = race))+
  facet_wrap(~alcallbin, nrow = 2)+
  ggtitle("PCA Plot of PC1 vs PC2 for race and drinking status")+
  xlab("PC1")+
  ylab("PC2")

library(tidyverse)
EurBlack1<- EurBlack1
EurBlack1$centre_name <- as.character(EurBlack$centre_name)
EurBlack1$centre_name[EurBlack1$centre_name == "11012"] <- "Barts"
EurBlack1$centre_name[EurBlack1$centre_name == "11021"] <- "Birmingham" 
EurBlack1$centre_name[EurBlack1$centre_name == "11008"] <- "Bury"
EurBlack1$centre_name[EurBlack1$centre_name == "11003"] <- "Cardiff"
EurBlack1$centre_name[EurBlack1$centre_name == "11024"] <- "Cheadle(revisit)"
EurBlack1$centre_name[EurBlack1$centre_name == "11020"] <- "Croydon"
EurBlack1$centre_name[EurBlack1$centre_name == "11005"] <- "Endiburgh"
EurBlack1$centre_name[EurBlack1$centre_name == "11004"] <- "Glasgow"
EurBlack1$centre_name[EurBlack1$centre_name == "11018"] <- "Hounslow"
EurBlack1$centre_name[EurBlack1$centre_name == "11010"] <- "Leeds"
EurBlack1$centre_name[EurBlack1$centre_name == "11016"] <- "Liverpool"
EurBlack1$centre_name[EurBlack1$centre_name == "11001"] <- "Manchester"
EurBlack1$centre_name[EurBlack1$centre_name == "11017"] <- "Newcastle"
EurBlack1$centre_name[EurBlack1$centre_name == "11009"] <- "Nottingham"
EurBlack1$centre_name[EurBlack1$centre_name == "11013"] <- "Oxford"
EurBlack1$centre_name[EurBlack1$centre_name == "11002"] <- "Reading"
EurBlack1$centre_name[EurBlack1$centre_name == "11007"] <- "Shiffield"
EurBlack1$centre_name[EurBlack1$centre_name == "11014"] <- "Stockport(pilot)"
EurBlack1$centre_name[EurBlack1$centre_name == "10003"] <- "Stoke"
EurBlack1$centre_name[EurBlack1$centre_name == "11006"] <- "Swansea"
EurBlack1$centre_name[EurBlack1$centre_name == "11022"] <- "Wrexham"
EurBlack1$centre_name[EurBlack1$centre_name == "11025"] <- "Cheadle (imaging)"
EurBlack1$centre_name[EurBlack1$centre_name == "11026"] <- "Reading (imaging)"
EurBlack1$centre_name[EurBlack1$centre_name == "11027"] <- "Newcastle (imaging)"
EurBlack1$centre_name[EurBlack1$centre_name == "11028"] <- "Bristol (imagining)"


ggplot(EurBlack1, aes(PC1, PC2))+
  geom_point(mapping = aes(color = race, shape = race))+
  facet_wrap(~sex, nrow = 2)+
  ggtitle("PCA Plot of PC1 vs PC2 for race and sex")+
  xlab("PC1")+
  ylab("PC2")

ggplot(EurBlack1, aes(PC1, PC4))+
  geom_point(mapping = aes(color = race, shape = race))+
  facet_wrap(~sex, nrow = 2)+
  ggtitle("PCA Plot of PC1 vs PC2 for race and sex")+
  xlab("PC1")+
  ylab("PC2")


ggplot(EurBlack1, aes(PC1, PC4))+
  geom_point(mapping = aes(color = race, shape = race))+
  facet_wrap(~sex, nrow = 2)+
  ggtitle("PCA Plot of PC1 vs PC4 for race and sex")+
  xlab("PC1")+
  ylab("PC2")

table(analysis$race)

library(ggplot2)
ggplot(EurBlack1, aes(ages, centre_name, col = race))+
  geom_bar(stat = "identity", fill = "white")+
  ggtitle("The ")+
  xlab("PC1")+
  ylab("PC2")

ggplot(EurBlack1, aes(PC1, PC3))+
  geom_point(mapping = aes(color = race))+
  facet_wrap(~smallbin, nrow = 2)+
  ggtitle("PCA Plot of PC1 vs PC2 for race and Smoking status")+
  xlab("PC1")+
  ylab("PC2")

ggplot(EurBlack1, aes(PC1, PC2))+
  geom_point(mapping = aes(color = race, shape = race))+
  facet_wrap(~sex, nrow = 2)+
  ggtitle("PCA Plot of PC1 vs PC2 for race and sex")+
  xlab("PC1")+
  ylab("PC2")

table(EurBlack1$race)
class(EurBlack1$race)

fish_snp
if (!require("pacman")) install.packages("pacman")
pacman::p_load(MendelianRandomization)
setwd("C:/Users/owner/Desktop/R/Internship") #Change with your location
#ratio.all<-as.matrix(read.csv("summarized_data.csv", row=1))
f.data = read.csv("fish_snp.csv")
attach(f.data) #Attach coursedata to the R search path 
MRObject = mr_input(bx = beta.exposure, bxse = se.exposure, 
                     by = beta.outcome, byse = se.outcome,snps = SNP)
#bx.all=ratio.all["bx",]
#by.all=ratio.all["by",]
#bxse.all=ratio.all["bxse",]
#byse.all=ratio.all["byse",]
#MRObject = mr_input(bx = bx.all, bxse = bxse.all, by = by.all, byse = byse.all)

mr_ivw(MRObject, model = "fixed")

mr_ivw(MRObject, model = "random")


# scatter plot
mr_plot(MRObject)


mr_egger(
  MRObject,
  robust = FALSE,
  penalized = FALSE,
  correl = FALSE,
  distribution = "normal",
  alpha = 0.05,
  ...
)

help("mr_egger")

# single snp plot
mr_forest(MRObject, ordered=TRUE)

# leave one out plot
mr_loo(MRObject)

# funnel plot
mr_funnel(MRObject)


#Explore Fish data
#add more coloum to analysis
#bd[c("No of tim")]<-c(analysis$centre)
 


if (!require("pacman")) install.packages("pacman")
pacman::p_load(MendelianRandomization)
setwd("C:/Users/owner/Desktop/R/Internship") #Change with your location
#ratio.all<-as.matrix(read.csv("summarized_data.csv", row=1))
f.data2 = read.csv("fish.data2.csv")
attach(f.data2) #Attach coursedata to the R search path 
MRObject = mr_input(bx = beta.exposure, bxse = se.exposure, 
                    by = beta.outcome, byse = se.outcome,snps = SNP)
#bx.all=ratio.all["bx",]
#by.all=ratio.all["by",]
#bxse.all=ratio.all["bxse",]
#byse.all=ratio.all["byse",]
#MRObject = mr_input(bx = bx.all, bxse = bxse.all, by = by.all, byse = byse.all)

mr_ivw(MRObject, model = "fixed")

mr_ivw(MRObject, model = "random")


# scatter plot
mr_plot(MRObject)


mr_egger(MRObject,
  robust = FALSE,
  penalized = FALSE,
  correl = FALSE,
  distribution = "normal",
  alpha = 0.05)

#help("mr_egger")

# single snp plot
mr_forest(MRObject, ordered=TRUE)

# leave one out plot
mr_loo(MRObject)

# funnel plot
mr_funnel(MRObject)

library(dplyr)

fish<-fish %>%
  rowwise() %>%
  mutate(
    Ate_fish = sum(f.103140.0.0,
                     f.103140.1.0,
                     f.103140.2.0,
                     f.103140.3.0,
                     f.103140.4.0,
                     na.rm = TRUE)
  )
 
fish1<-na.omit(fish)
rm(fish1)

library(tidyr)
fish1<-fish %>% drop_na()

fish$Ate_fish = NULL
rm(fish)

fish1<-fish[rowSums(is.na(fish) != ncol(fish)), ]#remove rows with empty cells

fish$Ate_fish <- rowSums(is.na(fish[2:6]))#create a sum in a new column the no of nas
#fish$NaNo <- ifelse(fish$Ate_fish < 4, rowSums(fish[2:6], na.rm = TRUE), NA)
fish$NaNo = NULL

fish1<-fish[fish$Ate_fish !=5, ] #remove all colums not equall to 5

fish$Ate <- rowSums(!is.na(fish[2:6]))#create a sum in a new column the no of nas

fish<-fish[fish$Ate !=0, ] #remove all colums equall to 0

fish$Ate = NULL

fish$ntimes<-rowSums(fish[2:6], na.rm = TRUE) # create new roll that has mumber of times participants ate fish

class(fish$ntimes)

fish$eater<- fish$ntimes

fish$eater[fish$eater %in% c (1, 2, 3, 4, 5)] <- 1 # create binary for fish/non eaters

fish$f.103140.0.0 = NULL
fish$f.103140.1.0 = NULL
fish$f.103140.2.0 = NULL
fish$f.103140.3.0 = NULL
fish$f.103140.4.0 = NULL #remove other columns

#merge fish data to analysis data

colnames(fish)[1]<-"idno"

#merge two data sets, fish and analysis
Fishdata<-merge(fish, EurBlack1, key=idno)#this returns the desired outcome
#Fishdata1<-merge(fish, EurBlack1, key=idno)#this returns the desired outcome
rm(Fishdata1)

colnames(Fishdata)[2]<-"nTimes"
colnames(Fishdata)[3]<-"FishStatus"

table(Fishdata$race2)
table(Fishdata$race)

library(ggplot2)

#plot for fish eaters vs non
#Change the ancestries from numeric to Characters
Fishdata$Ancestry <- Fishdata$race
Fishdata$Ancestry <- as.character(Fishdata$Ancestry)
Fishdata$Ancestry[Fishdata$Ancestry == "1"] <- "EUR"
Fishdata$Ancestry[Fishdata$Ancestry == "2"] <- "MIX"
Fishdata$Ancestry[Fishdata$Ancestry == "3"] <- "AFR"
Fishdata$Ancestry[Fishdata$Ancestry == "4"] <- "IND"
Fishdata$Ancestry[Fishdata$Ancestry == "6"] <- "OTH"
Fishdata$Ancestry[Fishdata$Ancestry == "8"] <- "OTH"

ggplot(Fishdata, aes(FishStatus, colour = Ancestry, fill = Ancestry))+
  geom_bar(width = 0.5)+
  ggtitle("Distribution of Fish Eaters")+
  xlab("Fish eating status")+
  ylab("Number of fish eaters")

  

ggplot(Fishdata, aes(x = FishStatus, colour = Ancestry, fill = Ancestry))+
  geom_bar(width = 0.5, color = "white")+
  coord_polar(theta = "x")+
  ggtitle("Distribution of Fish Eaters")
  #xlab("Fish eating status")+
  #ylab("Number of fish eaters")

