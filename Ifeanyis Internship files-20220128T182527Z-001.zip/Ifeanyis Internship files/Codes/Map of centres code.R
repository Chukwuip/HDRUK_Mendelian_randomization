#remove some unwanted dataframes from the global environment
rm(blackkdata1)
rm(lbl.100010)
rm(lvl.100010)
rm(qblacks)
rm(Ukb.all)
rm(snp_readBGEN)
rm(ukb_self_reported_black_pcs)
rm(qEuridpc)
rm(qblack_pcs)
rm(qblack1)
rm(qblack)
rm(black_sr)
rm(qEur_pcs)
rm(black_pcs)
rm(blackdata)
rm(Eur_QCp_PCs)
rm(ukb_qced_black_ids)
rm(data)



# Libraries
library(ggplot2)
library(dplyr)

# FIRST STEP Get the world polygon and extract UK
library(maps)
UK <- map_data("world") %>% filter(region=="UK")

UK
#Second Step



# Get a data frame with longitude, latitude, and size of bubbles (a bubble = a city)
data <- world.cities %>% filter(country.etc=="UK")

class(data$lat)

#create new column for centre name and make
colnames(data)[1]<-"centre_name"

table(EurBlack$centre_name)

library(tidyverse)
EurBlack1<- analysis
EurBlack1$centre_name <- as.character(analysis$centre_name)
EurBlack1$centre_name[EurBlack1$centre_name == "11012"] <- "Barts"
EurBlack1$centre_name[EurBlack1$centre_name == "11021"] <- "Birmingham" 
EurBlack1$centre_name[EurBlack1$centre_name == "11011"] <- "Bristol"
EurBlack1$centre_name[EurBlack1$centre_name == "11008"] <- "Bury"
EurBlack1$centre_name[EurBlack1$centre_name == "11003"] <- "Cardiff"
EurBlack1$centre_name[EurBlack1$centre_name == "11020"] <- "Croydon"
EurBlack1$centre_name[EurBlack1$centre_name == "11005"] <- "Edinburgh"
EurBlack1$centre_name[EurBlack1$centre_name == "11004"] <- "Glasgow"
EurBlack1$centre_name[EurBlack1$centre_name == "11018"] <- "Hounslow"
EurBlack1$centre_name[EurBlack1$centre_name == "11010"] <- "Leeds"
EurBlack1$centre_name[EurBlack1$centre_name == "11016"] <- "Liverpool"
EurBlack1$centre_name[EurBlack1$centre_name == "11001"] <- "Manchester"
EurBlack1$centre_name[EurBlack1$centre_name == "11017"] <- "Middlesborough"
EurBlack1$centre_name[EurBlack1$centre_name == "11009"] <- "Newcastle"
EurBlack1$centre_name[EurBlack1$centre_name == "11013"] <- "Nottingham"
EurBlack1$centre_name[EurBlack1$centre_name == "11002"] <- "Oxford"
EurBlack1$centre_name[EurBlack1$centre_name == "11007"] <- "Reading"
EurBlack1$centre_name[EurBlack1$centre_name == "11014"] <- "Sheffield"
EurBlack1$centre_name[EurBlack1$centre_name == "10003"] <- "Stockport"
EurBlack1$centre_name[EurBlack1$centre_name == "11006"] <- "Stoke"
EurBlack1$centre_name[EurBlack1$centre_name == "11022"] <- "Swansea"
EurBlack1$centre_name[EurBlack1$centre_name == "11023"] <- "Wrexham"

#Creat new column for Lat and Long
EurBlack1$Lat<-EurBlack1$centre_name
EurBlack1$Lat[EurBlack1$Lat == "Barts"] <- "51.39"
EurBlack1$Lat[EurBlack1$Lat == "Birmingham"] <- "52.48"
EurBlack1$Lat[EurBlack1$Lat == "Bristol"] <- "51.46"
EurBlack1$Lat[EurBlack1$Lat == "Bury"] <- "53.6"
EurBlack1$Lat[EurBlack1$Lat == "Cardiff"] <- "51.48"
EurBlack1$Lat[EurBlack1$Lat == "Croydon"] <- "51.37"
EurBlack1$Lat[EurBlack1$Lat == "Edinburgh"] <- "55.95"
EurBlack1$Lat[EurBlack1$Lat == "Glasgow"] <- "55.87"
EurBlack1$Lat[EurBlack1$Lat == "Hounslow"] <- "51.46"
EurBlack1$Lat[EurBlack1$Lat == "Leeds"] <- "53.81"
EurBlack1$Lat[EurBlack1$Lat == "Liverpool"] <- "53.42"
EurBlack1$Lat[EurBlack1$Lat == "Manchester"] <- "53.48"
EurBlack1$Lat[EurBlack1$Lat == "Middlesborough"] <- "54.58"
EurBlack1$Lat[EurBlack1$Lat == "Newcastle"] <- "55"
EurBlack1$Lat[EurBlack1$Lat == "Nottingham"] <- "52.97"
EurBlack1$Lat[EurBlack1$Lat == "Oxford"] <- "51.76"
EurBlack1$Lat[EurBlack1$Lat == "Reading"] <- "51.45"
EurBlack1$Lat[EurBlack1$Lat == "Sheffield"] <- "53.39"
EurBlack1$Lat[EurBlack1$Lat == "Stockport"] <- "53.42"
EurBlack1$Lat[EurBlack1$Lat == "Stoke"] <- "53.01"
EurBlack1$Lat[EurBlack1$Lat == "Swansea"] <- "51.63"
EurBlack1$Lat[EurBlack1$Lat == "Wrexham"] <- "53.05"

EurBlack1$Long<-EurBlack1$centre_name

EurBlack1$Long[EurBlack1$Long == "Barts"] <- "-2.38"
EurBlack1$Long[EurBlack1$Long == "Birmingham"] <- "-1.91"
EurBlack1$Long[EurBlack1$Long == "Bristol"] <- "-2.6"
EurBlack1$Long[EurBlack1$Long == "Bury"] <- "-2.31"
EurBlack1$Long[EurBlack1$Long == "Cardiff"] <- "-3.18"
EurBlack1$Long[EurBlack1$Long == "Croydon"] <- "-0.1"
EurBlack1$Long[EurBlack1$Long == "Edinburgh"] <- "-3.22"
EurBlack1$Long[EurBlack1$Long == "Glasgow"] <- "-4.27"
EurBlack1$Long[EurBlack1$Long == "Hounslow"] <- "-0.37"
EurBlack1$Long[EurBlack1$Long == "Leeds"] <- "-1.55"
EurBlack1$Long[EurBlack1$Long == "Liverpool"] <- "-2.99"
EurBlack1$Long[EurBlack1$Long == "Manchester"] <- "-2.25"
EurBlack1$Long[EurBlack1$Long == "Middlesborough"] <- "-1.23"
EurBlack1$Long[EurBlack1$Long == "Newcastle"] <- "-1.6"
EurBlack1$Long[EurBlack1$Long == "Nottingham"] <- "-1.18"
EurBlack1$Long[EurBlack1$Long == "Oxford"] <- "-1.26"
EurBlack1$Long[EurBlack1$Long == "Reading"] <- "-0.98"
EurBlack1$Long[EurBlack1$Long == "Sheffield"] <- "-1.48"
EurBlack1$Long[EurBlack1$Long == "Stockport"] <- "-2.17"
EurBlack1$Long[EurBlack1$Long == "Stoke"] <- "-2.19"
EurBlack1$Long[EurBlack1$Long == "Swansea"] <- "-3.96"
EurBlack1$Long[EurBlack1$Long == "Wrexham"] <- "-3"

as.numeric(EurBlack1$Lat)
as.numeric(EurBlack1$Long)
table(EurBlack1$Long)

library(ggplot2)
library(maps)

Centre_counts <- EurBlack1 %>%
  group_by(idno, centre_name,
           race, ages,
           Long, Lat) %>%
  tally()


ggplot() +
  geom_polygon(data = UK, aes(x=long, y = lat, group = group), fill="grey", alpha=0.3) +
  geom_point(data=Centre_counts, aes(x=as.numeric(Long), y=as.numeric(Lat),
                                     size = sum(n), color = as.character(race),
                                     alpha = .7)) +
  theme_void()


worldmap = map_data("world")

 

library(tidyverse)
library(dplyr)
library(ggrepel) 

ggplot() + 
  geom_polygon(data = worldmap, 
               aes(x = long, y = lat, group = group), 
               fill = 'gray90', color = 'black') + 
  coord_fixed(ratio = 1.3, xlim = c(-10,3), ylim = c(50, 59)) + 
  theme_void()+ 
  geom_point(data = Centre_counts, aes(x = as.numeric(Long),
                                       y = as.numeric(Lat),
                                       alpha=n, color = as.character(race)))


#Plot Map for fish data

library(ggplot2)
library(maps)

Centre_count1 <- Fishdata %>%
  group_by(idno, centre_name,
           race, ages,
           Long, Lat) %>%
  tally()


ggplot() +
  geom_polygon(data = UK, aes(x=long, y = lat, group = group), fill="grey", alpha=0.3) +
  geom_point(data=Centre_count1, aes(x=as.numeric(Long), y=as.numeric(Lat),
                                     size = sum(n), color = as.character(race),
                                     alpha = .7)) +
  theme_void()


worldmap = map_data("world")



library(tidyverse)
library(dplyr)
library(ggrepel) 

ggplot() + 
  geom_polygon(data = worldmap, 
               aes(x = long, y = lat, group = group), 
               fill = 'gray90', color = 'black') + 
  coord_fixed(ratio = 1.3, xlim = c(-10,3), ylim = c(50, 59)) + 
  theme_void()+ 
  geom_point(data = Centre_counts, aes(x = as.numeric(Long),
                                       y = as.numeric(Lat),
                                       alpha=n, color = as.character(race)))