#remove unwanted data frames from the global environment
rm(blackkdata1)
rm(lbl.100010)
rm(lvl.100010)
rm(qblacks)
rm(Ukb.all)
rm(snp_readBGEN)
rm(ukb_self_reported_black_pcs)
rm(qEuridpc)
rm(qblack_pcs)
rm(qblack1)
rm(qblack)
rm(black_sr)
rm(qEur_pcs)
rm(black_pcs)
rm(blackdata)
rm(Eur_QCp_PCs)
rm(ukb_qced_black_ids)
rm(data)
rm(newreg)
rm(newreg1)

library(ggplot2)
library(tidyverse)

library(ggplot2)
ggplot(EurBlack1, aes(centre_name))+
  geom_bar(fill = sex)+
  coord_flip()

library(ggplot2)
ggplot(Fishdata, aes(fill = as.character(eater), x= centre_name))+
  geom_bar(position = "dodge")+
  coord_flip()+
  ggtitle("Location of Fish eaters")

library(ggplot2)
ggplot(Fishdata, aes(fill = as.character(eater), x= sex))+
  geom_bar(position = "dodge")+
  coord_flip()+
  ggtitle("sex of fish eaters")

library(ggplot2)
ggplot(Fishdata, aes(fill = as.character(eater), x= sex))+
  geom_bar(position = "dodge")+
  coord_flip()+
  ggtitle("sex and age of fish eaters")



colnames(rs_fish)[1]<-"genid"

rs_fish<-merge(rs_fish, AdiposityID_sampleset, key=FID)#merge rs_fish and Adiposity

rs_fish<-merge(rs_fish, analysis, key=genid)#merge rs_fish and analysis

library(tidyverse)
rs_fish<- rs_fish %>%
  select(idno, everything())

colnames(fish)[3]<-"FishEater"

library(tidyverse)
fish<- fish %>%
  select(idno, FishEater, everything())

rs_fish<-merge(fish, rs_fish, key=idno)#merge fish eating data and rs_fish 

library(tidyverse)
#Save the data
save(rs_fish, file="C:/Users/Owner/Desktop/R/Internship/rs_fish.Rdata")
load(file="C:/Users/Owner/Desktop/R/Internship/Fishsnps/fish2.r")

attach(rs_fish)#attach rs_fish data

plot(FishEater, rs16834168, main = "Scatter Plot")

plot(ntimes, rs16834168, main = "Scatter Plot  of no of times fish is eaten")

cor(FishEater, rs16834168)

pairs(~FishEater + rs11066015+rs11066132+rs116977843+
        rs116977843_1+rs11758482+rs11877506+rs12003047+
        rs1201914)

pairs(~FishEater +rs144504271+rs1562806+rs16834168+
        rs17396472+rs1860343)

pairs(~FishEater + rs11066015+rs11066132+rs116977843+
        rs116977843_1+rs11758482+rs11877506+rs12003047+
        rs1201914+rs144504271+rs1562806+rs16834168+
        rs17396472+rs1860343+rs2456163+rs3782886+
        rs671+rs7206790+rs7476409+rs9502823)
cor(ntimes, rs16834168)

rs_fish$PC1<-as.numeric(rs_fish$PC1)
rs_fish$PC2<-as.numeric(rs_fish$PC2)
rs_fish$PC3<-as.numeric(rs_fish$PC3)
rs_fish$PC4<-as.numeric(rs_fish$PC4)
rs_fish$PC5<-as.numeric(rs_fish$PC5)
rs_fish$PC6<-as.numeric(rs_fish$PC6)
rs_fish$PC7<-as.numeric(rs_fish$PC7)
rs_fish$PC8<-as.numeric(rs_fish$PC8)
rs_fish$PC9<-as.numeric(rs_fish$PC9)
rs_fish$PC10<-as.numeric(rs_fish$PC10)
rs_fish$ages<-as.numeric(rs_fish$ages)
rs_fish$sex<-as.numeric(rs_fish$sex)

class(rs_fish$FishEater)
class(rs_fish$sex)
table(rs_fish$sex)

lm(FishEater~ages+sex+rs16834168+PC1+PC2)


lm(rs_fish[1:100,]$FishEater ~ rs_fish[1:100,]$ages+ rs_fish[1:100,]$sex+
     rs_fish[1:100,]$rs16834168+ rs_fish[1:100,]$PC1+  rs_fish[1:100,]$PC2)

lm(rs_fish[1:10000,]$FishEater ~ rs_fish[1:10000,]$ages+ rs_fish[1:10000,]$sex+
     rs_fish[1:10000,]$rs16834168+ rs_fish[1:10000,]$PC1+
     rs_fish[1:10000,]$PC2)

detach(rs_fish)

with(rs_fish, lm(FishEater~ages+sex+rs16834168+PC1+PC2))

newreg<-with(rs_fish, lm(FishEater~ages+sex+rs16834168+PC1+PC2))

summary(newreg)    

snp1<-with(rs_fish, glm(FishEater~ages+sex+rs16834168+PC1+PC2,
                          family="binomial"))#using general regression for log reggresion


summary(rs_fish$ntimes)

snp2<-with(rs_fish, glm(FishEater~ages+sex+ rs11066015+PC1+PC2,
                        family="binomial"))

snp3<-with(rs_fish, glm(FishEater~ages+sex+rs11066132+PC1+PC2,
                        family="binomial"))

snp4<-with(rs_fish, glm(FishEater~ages+sex+rs116977843+PC1+PC2,
                        family="binomial"))

snp5<-with(rs_fish, glm(FishEater~ages+sex+rs116977843_1+PC1+PC2,
                        family="binomial"))

snp6<-with(rs_fish, glm(FishEater~ages+sex+rs11758482+PC1+PC2,
                        family="binomial"))

snp7<-with(rs_fish, glm(FishEater~ages+sex+rs11877506+PC1+PC2,
                        family="binomial"))

snp8<-with(rs_fish, glm(FishEater~ages+sex+rs12003047+PC1+PC2,
                        family="binomial"))

snp9<-with(rs_fish, glm(FishEater~ages+sex+rs1201914+PC1+PC2,
                        family="binomial"))

snp10<-with(rs_fish, glm(FishEater~ages+sex+rs144504271+PC1+PC2,
                        family="binomial"))

snp11<-with(rs_fish, glm(FishEater~ages+sex+rs1562806+PC1+PC2,
                        family="binomial"))

snp12<-with(rs_fish, glm(FishEater~ages+sex+rs17396472+PC1+PC2,
                        family="binomial"))

snp13<-with(rs_fish, glm(FishEater~ages+sex+rs1860343+PC1+PC2,
                        family="binomial"))

snp14<-with(rs_fish, glm(FishEater~ages+sex+rs2456163+PC1+PC2,
                        family="binomial"))

snp15<-with(rs_fish, glm(FishEater~ages+sex+rs3782886+PC1+PC2,
                        family="binomial"))

snp16<-with(rs_fish, glm(FishEater~ages+sex+rs671+PC1+PC2,
                         family="binomial"))

snp17<-with(rs_fish, glm(FishEater~ages+sex+rs7206790+PC1+PC2,
                         family="binomial"))

snp18<-with(rs_fish, glm(FishEater~ages+sex+rs7476409+PC1+PC2,
                         family="binomial"))

snp19<-with(rs_fish, glm(FishEater~ages+sex+rs9502823+PC1+PC2,
                         family="binomial"))

summary(snp2)
summary(snp3)
summary(snp4)
summary(snp5)
summary(snp6)
summary(snp7)
summary(snp8)
summary(snp9)
summary(snp10)
summary(snp11)
summary(snp12)
summary(snp13)
summary(snp14)
summary(snp15)
summary(snp16)
summary(snp17)
summary(snp18)
summary(snp19)

library(dplyr)
library(tidyverse)
rm(oilfish)

Fish2<- bd[, !(names(bd) %in% c("f.103140.0.0", "f.103140.1.0", "f.103140.2.0",
   "f.103140.3.0", "f.103140.4.0"))] #remove columns

#Otherfish<-Otherfish[rowSums(is.na(Otherfish) != ncol(Otherfish)), ]#remove rows with empty cells

summary(Fish2)
Fish2$Atefish <- rowSums(is.na(Fish2[2:31]))#create a sum in a new column the no of nas
#fish$NaNo <- ifelse(fish$Ate_fish < 4, rowSums(fish[2:6], na.rm = TRUE), NA)
#fish$NaNo = NULL

Otherfish<-Otherfish[Otherfish$Atefish !=21, ] #remove all colums not equall to 5

fish$Ate <- rowSums(!is.na(fish[2:6]))#create a sum in a new column the no of nas

Fish2<-Fish2[Fish2$Atefish !=30, ] #remove all colums equall to 0

fish$Ate = NULL

Fish2$notimes<-rowSums(Fish2[2:31], na.rm = TRUE) # create new roll that has mumber of times participants ate fish

class(fish$ntimes)

fish$eater<- fish$ntimes

fish$eater[fish$eater %in% c (1, 2, 3, 4, 5)] <- 1 # create binary for fish/non eaters

