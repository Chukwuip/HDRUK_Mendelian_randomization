library(ggplot2)
#plot for race
library(tidyverse)
ggplot(rs_fish, aes(ntimes, as.numeric(calcium)))+
         geom_point(na.rm = TRUE)

class(rs_fish$hxdiabbin)  
class(rs_fish$FishEater)

t2D1<-with(rs_fish, glm(hxdiabbin~ages+sex+rs16834168+PC1+PC2+PC3+PC4+PC5+PC6+
                          PC7+PC8+PC9+PC10, family="binomial"))

t2D2<-with(rs_fish, glm(hxdiabbin~ages+sex+ rs11066015+PC1+PC2+PC3+PC4+PC5+
                          PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D3<-with(rs_fish, glm(hxdiabbin~ages+sex+rs11066132+PC1+PC2+PC3+PC4+PC5+
                          PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D4<-with(rs_fish, glm(hxdiabbin~ages+sex+rs116977843+PC1+PC2+PC3+PC4+PC5+
                          PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D5<-with(rs_fish, glm(hxdiabbin~ages+sex+rs116977843_1+PC1+PC2+PC3+PC4+PC5+
                          PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D6<-with(rs_fish, glm(hxdiabbin~ages+sex+rs11758482+PC1+PC2+PC3+PC4+PC5+
                          PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D7<-with(rs_fish, glm(hxdiabbin~ages+sex+rs11877506+PC1+PC2+PC3+PC4+PC5+
                          PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D8<-with(rs_fish, glm(hxdiabbin~ages+sex+rs12003047+PC1+PC2+PC3+PC4+PC5+
                          PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D9<-with(rs_fish, glm(hxdiabbin~ages+sex+rs1201914+PC1+PC2+PC3+PC4+PC5+
                          PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D10<-with(rs_fish, glm(hxdiabbin~ages+sex+rs144504271+PC1+PC2+PC3+PC4+PC5+
                           PC6+PC7+PC8+PC9+PC10,family="binomial"))

t2D11<-with(rs_fish, glm(hxdiabbin~ages+sex+rs1562806+PC1+PC2+PC3+PC4+PC5+
                           PC6+PC7+PC8+PC9+PC10 family="binomial"))

t2D12<-with(rs_fish, glm(hxdiabbin~ages+sex+rs17396472+PC1+PC2+PC3+PC4+PC5+
                           PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D13<-with(rs_fish, glm(hxdiabbin~ages+sex+rs1860343+PC1+PC2+PC3+PC4+PC5+
                           PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D14<-with(rs_fish, glm(hxdiabbin~ages+sex+rs2456163+PC1+PC2+PC3+PC4+PC5+
                           PC6+PC7+PC8+PC9+PC10,family="binomial"))

t2D15<-with(rs_fish, glm(hxdiabbin~ages+sex+rs3782886+PC1+PC2+PC3+PC4+PC5+
                           PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D16<-with(rs_fish, glm(hxdiabbin~ages+sex+rs671+PC1+PC2+PC3+PC4+PC5+
                           PC6+PC7+PC8+PC9+PC10,family="binomial"))

t2D17<-with(rs_fish, glm(hxdiabbin~ages+sex+rs7206790+PC1+PC2+PC3+PC4+PC5+
                           PC6+PC7+PC8+PC9+PC10,family="binomial"))

t2D18<-with(rs_fish, glm(hxdiabbin~ages+sex+rs7476409+PC1+PC2+PC3+PC4+PC5+
                           PC6+PC7+PC8+PC9+PC10, family="binomial"))

t2D19<-with(rs_fish, glm(hxdiabbin~ages+sex+rs9502823+PC1+PC2+PC3+PC4+PC5+
                           PC6+PC7+PC8+PC9+PC10,family="binomial"))

summary(t2D1)
summary(t2D2)
summary(t2D3)
summary(t2D4)
summary(t2D5)
summary(t2D6)
summary(t2D7)
summary(t2D8)
summary(t2D9)
summary(t2D10)
summary(t2D11)
summary(t2D12)
summary(t2D13)
summary(t2D14)
summary(t2D15)
summary(t2D16)
summary(t2D17)
summary(t2D18)
summary(t2D19)
