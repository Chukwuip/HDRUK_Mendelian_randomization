#remove unwated data frames from the global environment
rm(fishintake)
rm(Otherfish)
rm(qblackpcs)
rm(worldmap)
rm(bd1)
rm(bd2)
rm(blackpcs)
rm(EurBlack)
rm(nonblacks)
rm(newreg)
rm(newreg1)
rm(Eurdata)
rm(location)
rm(fish2)
rm(fish)
rm(Fish2)
rm(fish3)


# R program fish.tab created 2021-08-03 by ukb2r.cpp Mar 14 2018 16:01:22
bd2<-bd
bd<- read.table("C:/Users/Owner/Desktop/R/Internship/Fishsnps/fish3.tab", header=TRUE, sep="\t")
lvl.100377 <- c(-3,-1,0,1,2,3,4,5)
lbl.100377 <- c('NA',"NA",0,0.5,1,3,5.5,7)
bd$f.1329.0.0 <- ordered(bd$f.1329.0.0, levels=lvl.100377, labels=lbl.100377)
bd$f.1329.1.0 <- ordered(bd$f.1329.1.0, levels=lvl.100377, labels=lbl.100377)
bd$f.1329.2.0 <- ordered(bd$f.1329.2.0, levels=lvl.100377, labels=lbl.100377)
bd$f.1339.0.0 <- ordered(bd$f.1339.0.0, levels=lvl.100377, labels=lbl.100377)
bd$f.1339.1.0 <- ordered(bd$f.1339.1.0, levels=lvl.100377, labels=lbl.100377)
bd$f.1339.2.0 <- ordered(bd$f.1339.2.0, levels=lvl.100377, labels=lbl.100377)


colnames(bd)[2]<- "Oilyfish_intake"
colnames(bd)[5]<- "nonoilyfish_intake"
colnames(bd)[1]<- "idno"
as.numeric()
bd$f.1329.1.0 = NULL
bd$f.1329.2.0 = NULL
bd$f.1339.1.0 = NULL
bd$f.1339.2.0 = NULL

fishintake<-merge(bd, analysis, key=idno)

#colnames(sampleID_map)[1]<- "FID"

colnames(AdiposityID_sampleset)[1]<-"idno"

#sampleID<-merge(sampleID_map, AdiposityID_sampleset, Key=FID)

#rm(sampleID)
#rm(fishintake)

#colnames(sampleID)[2]<-"idno"

rm(fishintake)

fishintake<-merge(fishintake, AdiposityID_sampleset, Key = idno)


summary(sampleID$id)
summary(sampleID$BP_sample_ID)
summary(fishintake$idno)

#rm(rs_fish)
rsfish$rs116977843_1 = NULL

#arrange the data set
library(tidyverse)
#for all data set
fishintake<- fishintake %>%
  select(idno, FID, Oilyfish_intake, nonoilyfish_intake, everything())

colnames(rsfish)[1]<- "FID"
#merge with rs fish data

fishintake<-merge(fishintake, rsfish, key =FID)

table(fishintake$alcallamt)
class(fishintake$sex)

fishintake$sex<-as.numeric(fishintake$sex)

library(tidyverse)

#convert some values to numeric variables
fishintake$PC1<-as.numeric(fishintake$PC1)
fishintake$PC2<-as.numeric(fishintake$PC2)
fishintake$PC3<-as.numeric(fishintake$PC3)
fishintake$PC4<-as.numeric(fishintake$PC4)
fishintake$PC5<-as.numeric(fishintake$PC5)
fishintake$PC6<-as.numeric(fishintake$PC6)
fishintake$PC7<-as.numeric(fishintake$PC7)
fishintake$PC8<-as.numeric(fishintake$PC8)
fishintake$PC9<-as.numeric(fishintake$PC9)
fishintake$PC10<-as.numeric(fishintake$PC10)
fishintake$ages<-as.numeric(fishintake$ages)
fishintake$sex<-as.numeric(fishintake$sex)
fishintake$alcallbin<-as.numeric(fishintake$alcallbin)
fishintake$Oilyfish_intake<-as.numeric(fishintake$Oilyfish_intake)
fishintake$nonoilyfish_intake<-as.numeric(fishintake$nonoilyfish_intake)


class(fishintake$Oilyfish_intake)
class(fishintake$alcallamt)
table(fishintake$alcallamt)
summary(fishintake$alcallamt)

rm(snp1)
rm(snp2)
rm(snp3)
rm(snp4)
rm(snp5)
rm(snp6)

snp1<-with(fishintake, lm(nonoilyfish_intake~ages+sex+PC1+PC2+PC3+
                            PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs9502823))

snp2<-with(fishintake, lm(nonoilyfish_intake~ages+sex+PC1+PC2+PC3+
                            PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs17396472))

snp3<-with(fishintake, lm(nonoilyfish_intake~ages+sex+PC1+PC2+PC3+
                            PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs1860343))

snp4<-with(fishintake, lm(nonoilyfish_intake~ages+sex+PC1+PC2+PC3+
                            PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs11066015))

snp5<-with(fishintake, lm(nonoilyfish_intake~ages+sex+PC1+PC2+PC3+
                            PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs1201914))

snp6<-with(fishintake, lm(nonoilyfish_intake~ages+sex+PC1+PC2+PC3+
                            PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs671))

summary(snp1)
summary(snp2)
summary(snp3)
summary(snp4)
summary(snp5)
summary(snp6)



fishintake$centre_name <- as.character(fishintake$centre_name)
fishintake$centre_name[fishintake$centre_name == "11012"] <- "Barts"
fishintake$centre_name[fishintake$centre_name == "11021"] <- "Birmingham" 
fishintake$centre_name[fishintake$centre_name == "11011"] <- "Bristol"
fishintake$centre_name[fishintake$centre_name == "11008"] <- "Bury"
fishintake$centre_name[fishintake$centre_name == "11003"] <- "Cardiff"
fishintake$centre_name[fishintake$centre_name == "11020"] <- "Croydon"
fishintake$centre_name[fishintake$centre_name == "11005"] <- "Edinburgh"
fishintake$centre_name[fishintake$centre_name == "11004"] <- "Glasgow"
fishintake$centre_name[fishintake$centre_name == "11018"] <- "Hounslow"
fishintake$centre_name[fishintake$centre_name == "11010"] <- "Leeds"
fishintake$centre_name[fishintake$centre_name == "11016"] <- "Liverpool"
fishintake$centre_name[fishintake$centre_name == "11001"] <- "Manchester"
fishintake$centre_name[fishintake$centre_name == "11017"] <- "Middlesborough"
fishintake$centre_name[fishintake$centre_name == "11009"] <- "Newcastle"
fishintake$centre_name[fishintake$centre_name == "11013"] <- "Nottingham"
fishintake$centre_name[fishintake$centre_name == "11002"] <- "Oxford"
fishintake$centre_name[fishintake$centre_name == "11007"] <- "Reading"
fishintake$centre_name[fishintake$centre_name == "11014"] <- "Sheffield"
fishintake$centre_name[fishintake$centre_name == "10003"] <- "Stockport"
fishintake$centre_name[fishintake$centre_name == "11006"] <- "Stoke"
fishintake$centre_name[fishintake$centre_name == "11022"] <- "Swansea"
fishintake$centre_name[fishintake$centre_name == "11023"] <- "Wrexham"

library(tidyverse)
fishintake$rs671<-as.character(fishintake$rs671)
fishintake$rs1860343<-as.numeric(fishintake$rs1860343)

fishintake$rs1860343

fishintake$rs17396472

library(ggplot2)

round(0.95)
ceiling(0.0003)

library(dplyr)
library(tidyr)
unloadNamespace('tidyr')
unloadNamespace('dplyr')
detach_package('tidyr', TRUE)
rm(fishtakers)
#remove non fish eaters
fishtakers<-fishintake

library(tidyr)
fishtakers$Oilyfish_intake<-fishtakers$Oilyfish_intake %>% drop_na()

library(tidyverse)
fishtakers<-na.omit(fishtakers$Oilyfish_intake)
fishtakers<-na.omit(fishtakers$nonoilyfish_intake)
fishtakers[fishtakers$Oilyfish_intake !=0, ]
fishtakers[fishtakers$nonoilyfish_intake !=0, ]

summary(fishtakers$Oilyfish_intake)


fishtakers$Oilyfish_intake<- as.numeric(fishtakers$Oilyfish_intake)

library(dplyr)
#remove values based on condition
fishtakers<-filter(fishtakers, !is.na(fishtakers$Oilyfish_intake))
fishtakers<-filter(fishtakers, !is.na(fishtakers$nonoilyfish_intake))
fishtakers<-fishtakers[fishtakers$Oilyfish_intake !=0, ]
fishtakers<-fishtakers[fishtakers$nonoilyfish_intake !=0, ]

TwoXandmore<-fishtakers[fishtakers$Oilyfish_intake !=0 &
                          fishtakers$Oilyfish_intake !=0.5 &
                          fishtakers$Oilyfish_intake !=1, ]


MaleFisheaters<-TwoXandmore[TwoXandmore$sex !=2, ]

FemaleFisheaters<-TwoXandmore[TwoXandmore$sex !=1, ]



rm(femaleFisheaters)
summary(TwoXandmore$ages)
table(TwoXandmore$ages)

summary(fishtakers$ages)
table(MaleFisheaters$sex)


memory.size()

memory.limit(size = 56000)#increase memory capacity of R

round(fishintake$rs17396472)

fishintake$rs1860343<-as.character(fishintake$rs1860343)
fishintake$rs1860343



ggplot(fishintake, aes(rs9502823, Oilyfish_intake)) +
  geom_boxplot(aes(group =cut_width(rs9502823, 1)))

ggplot(fishintake, aes(rs17396472, Oilyfish_intake)) +
  geom_boxplot(aes(group =cut_width(rs17396472, 1)))

ggplot(fishintake, aes(rs11066015, Oilyfish_intake)) +
  geom_boxplot(aes(group =cut_width(rs11066015, 1)))

ggplot(fishintake, aes(rs1201914, Oilyfish_intake)) +
  geom_boxplot(aes(group =cut_width(rs1201914, 1)))

ggplot(fishintake, aes(rs1860343, Oilyfish_intake)) +
  geom_boxplot(aes(group =cut_width(rs1860343, 1)))



ggplot(fishintake, aes(rs671, Oilyfish_intake)) +
  geom_boxplot()

ggplot(fishintake, aes(alcallamt, rs671)) +
  geom_boxplot(aes(group =cut_width(alcallamt, 0.25)))

write.csv(fishintake, 'fishintake.csv')  



rm(snp1)
rm(snp2)
rm(snp3)
rm(snp4)
rm(snp5)


snp1<-with(TwoXandmore, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                             PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs9502823))

snp2<-with(TwoXandmore, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                             PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs17396472))

snp3<-with(TwoXandmore, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                             PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs1860343))

snp4<-with(TwoXandmore, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                             PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs11066015))

snp5<-with(TwoXandmore, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                             PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs1201914))

summary(snp1)
summary(snp2)
summary(snp3)
summary(snp4)
summary(snp5)

rm(snp1)
rm(snp2)
rm(snp3)
rm(snp4)
rm(snp5)


snp1<-with(MaleFisheaters, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                                PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs9502823))

snp2<-with(MaleFisheaters, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                                PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs17396472))

snp3<-with(MaleFisheaters, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                                PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs1860343))

snp4<-with(MaleFisheaters, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                                PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs11066015))

snp5<-with(MaleFisheaters, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                                PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs1201914))

summary(snp1)
summary(snp2)
summary(snp3)
summary(snp4)
summary(snp5)


rm(snp1)
rm(snp2)
rm(snp3)
rm(snp4)
rm(snp5)


snp1<-with(FemaleFisheaters, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                                  PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs9502823))

snp2<-with(FemaleFisheaters, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                                  PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs17396472))

snp3<-with(FemaleFisheaters, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                                  PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs1860343))

snp4<-with(FemaleFisheaters, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                                  PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs11066015))

snp5<-with(FemaleFisheaters, lm(Oilyfish_intake~ages+sex+PC1+PC2+PC3+
                                  PC4+PC5+PC6+PC7+PC8+PC9+PC10+rs1201914))

summary(snp1)
summary(snp2)
summary(snp3)
summary(snp4)
summary(snp5)


round(fishtakers$rs9502823)
round(fishintake$rs17396472)
round(fishintake$rs1860343)
round(fishintake$rs11066015)
round(fishintake$rs1201914)


round(MaleFisheaters$rs9502823)
round(MaleFisheaters$rs17396472)
round(MaleFisheaters$rs1860343)
round(MaleFisheaters$rs11066015)
round(MaleFisheaters$rs1201914)

ggplot(MaleFisheaters, aes(rs11066015, Oilyfish_intake)) +
  geom_boxplot(aes(group =cut_width(rs11066015, 1)))


Males<-fishintake[fishintake$sex !=2, ]

Females<-fishintake[fishintake$sex !=1, ]

save(fishtakers, file = "fishtakes.RData")
save(Males, file = "Male.RData")
save(Females, file = "Female.RData")



library(ggplot2)

ggplot(Males, aes(rs9502823, Oilyfish_intake)) +
  geom_boxplot(aes(group =cut_width(rs9502823, 1)))

ggplot(fishintake, aes(rs17396472, Oilyfish_intake)) +
  geom_boxplot(aes(group =cut_width(rs17396472, 1)))

ggplot(fishintake, aes(rs11066015, Oilyfish_intake)) +
  geom_boxplot(aes(group =cut_width(rs11066015, 1)))

ggplot(fishintake, aes(rs1201914, Oilyfish_intake)) +
  geom_boxplot(aes(group =cut_width(rs1201914, 1)))

ggplot(fishintake, aes(rs1860343, Oilyfish_intake)) +
  geom_boxplot(aes(group = cut_width(rs1860343, 1)))
